# مصادر وأساس الاستدلال

الأولوية للمشاهدة والتفاعل داخل الحساب. راجع [سجل الأدلة](EVIDENCE_LOG.md). أضيفت المصادر الرسمية التالية بعد تعطل الصفحات الداخلية لاستكمال السياق، دون استبدال الاختبار العملي بها. الاطلاع: 20 أكتوبر 2026. لا تُستخدم صورها كأنها صور من حساب المستخدم.

| ID | المصدر الرسمي | المعلومة المستفادة وحدودها |
|---|---|---|
| D01 | [Visual Flow Builder](https://botsailor.com/index.php/product/visual-flow-builder) | يصف التسليم للموظف والـAI والتسلسلات والتكاملات. وصف منتج، لا إثبات إتاحتها بالباقة الحالية. |
| D02 | [Duplicate, Export, Import](https://botsailor.com/help/en/blog/how-to-duplicate-export-and-import-a-bot-in-botsailor) | يشرح النسخ والتصدير والاستيراد من إدارة البوتات. الدليل يذكر JSON في المقدمة وملف TXT في الخطوات؛ صيغة الملف الفعلية لم تختبر. يذكر استبعاد مفاتيح وTokens ومعرّفات قوالب من التصدير. |
| D03 | [Less Configuration, More Automation](https://botsailor.com/index.php/blog/the-botsailor-upgrade-less-configuration-more-automation) | يصف تجميع المكتبة والبحث وفتح خصائص العقدة آليًا وإجراءات Hover. لم تختبر كل هذه الحالات بعينها. |
| D04 | [External HTTP API Integration](https://botsailor.com/index.php/blog/botsailor-http-api-integration-guide) | يشرح إعداد API وربط استجابته بالحقول ثم استخدامه داخل التدفق. لم ننشئ اتصالًا خارجيًا. |
| D05 | [Shared Inbox Updates: CRM & AI](https://botsailor.com/forum/thread/2699-botsailor-shared-inbox-updates-crm-ai-2026?page=1) | إعلان رسمي يصف Reply/Note والردود الجاهزة والترجمة والتحكم بالمحادثة. لا يثبت صلاحيات الحساب ولا كفاءة الواجهة الفعلية. |
| D06 | [Team Management for Resellers](https://botsailor.com/help/en/blog/botsailor-reseller-team-management) | يصف صلاحيات الأدوار وتقييد القنوات والمحادثات. خاص بسياق Reseller؛ لا نفترض انطباقه كاملًا على الحساب الحالي. |
| D07 | [Change Log](https://botsailor.com/blog/botsailors-change-log) | يذكر تحديث 24 مايو 2026 للمكتبة والخصائص وحذف الاتصال عند Hover، ويذكر دعم Recursive connection في 6 أبريل 2025. هذه أدلة توثيق فقط للحالات التي لم نختبرها. |
| D08 | [Conditions and Triggers](https://botsailor.com/help/en/blog/using-conditions-and-triggers-in-flow-builder-botsailor-automation-guide) | مرجع إضافي لتسلسل Trigger → User Input → Text → Condition. التجربة الحالية أكدت إنشاء هذه المكونات داخل المحرر، دون تشغيل حي. |

الصفحة العامة [BotSailor](https://botsailor.com/) فُتحت فعليًا وعملت بينما الصفحات الداخلية أعادت 500. أقوالها عن القنوات والميزات ادعاءات تسويقية لم تختبر على القنوات الأخرى.

## ما لم يستخدم

لم نستخدم تقارير سابقة لإثبات حالة Elhafez Boat؛ البحث في السياق والملفات لم يسترجع قائمة الـ36 الأصلية أو تقريرًا ذا صلة يمكن الاعتماد عليه. لم نفحص مستودعًا أو مصدرًا برمجيًا للمنصتين، ولم نجزم بسبب خطأ الخادم.
