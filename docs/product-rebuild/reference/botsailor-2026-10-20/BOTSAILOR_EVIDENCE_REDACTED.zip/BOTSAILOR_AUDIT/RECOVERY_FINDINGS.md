# نتائج الاستئناف بعد عودة الخدمة — المرجع الأحدث

هذا الملحق يحدّث حالة الوصول القديمة في التقارير، ولا يلغي وقوع العطل. تاريخ العمل20 أكتوبر2026. الصفحات التي لم تُعد زيارتها بعد العطل تبقى غير متحققة؛ لا نفترض أنها عادت لمجرد عودة Dashboard.

## النتائج الحالية المثبتة

| القسم | ما جرى بعد عودة الخدمة | الحالة النهائية | الإثبات |
|---|---|---|---|
| Dashboard | أعيد التحميل وعادت التحية والبطاقات والمخططات | V بصريًا؛ لم نختبر صحة الأرقام | مشاهدة مباشرة، دون لقطة محفوظة للحالة السليمة |
| Bot Manager | البحث AUDIT ONLY أعاد التدفق الخاص بنا؛ فتح Edit | T بحث وفتح | [031](SCREENSHOTS/031_botmanager_saved_test.jpg) |
| إعادة فتح المصمم | عاد نفس العنوان والكلمة والرسائل والحقول والشرط؛ عددDOM:10 عقد و9 وصلات | T إعادة فتح نسخة محفوظة؛ آخر فرعين غير محفوظين | [032](SCREENSHOTS/032_saved_flow_reopened.jpg) |
| Message Templates | Create يعرض Mixed/WP/Carousel Media/Carousel Product؛ فتح Mixed وكتابة Header/Body بالعربية | T تحرير محلي وV معاينة | [033](SCREENSHOTS/033_template_live_preview.jpg) |
| تحقق اسم القالب | اسم audit_20261020_travel_draft رُفض؛ الرسالة تسمح lower-case letters وunderscores فقط | T رفض الاسم؛ صُحح إلى audit_travel_review_only | [034](SCREENSHOTS/034_template_name_error.jpg) |
| Save Draft للقالب | ضغطنا Save Draft فقط؛ ظهر سجل462028 باسم audit_travel_review_only مع(Custom) وحالةSubmitted | T ظهور سجل؛ دلالةDraft/Submitted متعارضة | [035](SCREENSHOTS/035_template_after_save_draft.jpg) |
| Follow-up Sequences | فتحت القائمة؛ Create وBulk Assign وProcessed/Delivered/Opened/Unreached/Last Sent | V؛ لم ننشئ أو نسند تسلسلًا | [036](SCREENSHOTS/036_sequences_list.jpg) |
| Quick Actions | ظهرت Get-started،No Match،Location،Unsubscribe،Resubscribe،Chat with Human،Chat with Bot | V لوجود المسارات الافتراضية؛ لم نعدلها أو نشغلها | [037](SCREENSHOTS/037_quick_actions.jpg) |
| Webhook Workflows | فتح Create؛ Workflow name وMessage Template وPreview وAI Workflow Assistant | V نموذج؛ لا إنشاء/اختبار/استدعاء | [038](SCREENSHOTS/038_webhook_create.jpg) |
| User Input Flows | البحث أظهر حملتنا AUDIT_20261020_Travel_Lead معReport/Export/Edit | T بقاء الحملة؛ V أدوات تقرير/تصدير | [039](SCREENSHOTS/039_inputflow_saved.jpg) |
| AI Configuration | Toggle معطل وSave Settings؛ لم نفعله | V فقط | [040](SCREENSHOTS/040_ai_configuration.jpg) |
| AI Agents | قائمة فارغة؛ Create Agent فتح الاسم والSlug والوصف والPrompt ومصادرContent/URL/File/Media/Google Sheet/API | V نموذج؛ لم يحفظ وكيلًا أو يدرب | [041](SCREENSHOTS/041_ai_agent_form.jpg) |
| Integration Settings | من Integrations انتقل إلىSettings/Auto Responder؛ New فتح Profile/API Key ومزوديMailchimp/Brevo/ActiveCampaign/Mautic/MailWizz | V نموذج فارغ فقط؛ لا اتصال خارجي | [042](SCREENSHOTS/042_integration_empty_form.jpg) |
| Security Settings | دخلنا تبويب الأمان؛ تنقلDevices/Login activity/Delete activity/Direct Login/IP Manager ظاهر | V تنقل فقط؛ لم تُصوّر بيانات الجلسات أوIP ولم نغير شيئًا | AX أثناء الجلسة |
| User Manager | فتحت القائمة بأعمدة Roles/Status؛ Create انتقل إلىصفحة403:You do not have permission to access this | V قائمة؛ B صلاحية إنشاء | AX؛ لا لقطة محفوظة لصفحة403 |

## استنتاج الحفظ — ما تغير عن المرحلة الأولى

آخر رسم داخل المتصفح قبل الخطأ كان12 عقدة و11 وصلة. النسخة التي أعيد فتحها من الخادم تحتوي10 عقد و9 وصلات، وتشمل الشرط دون الرسالتين النهائيتين لمخرجيTrue وFalse. إذن الحفظ الأول قابل لإعادة الفتح، أما التعديلات اللاحقة على الفرعين فلم تظهر في النسخة المحفوظة. لا نعرف سبب فشل الحفظ، ولا نستنتج تلفًا في النسخة الأولى.

التدفق المحفوظID2177942؛ الحملةID322550. لا يوجد اختبار لإعادة فتح نسخة جديدة بعد تصحيح الفرعين؛ لم نكمل إنشاءهما مجددًا قبل طلب تسليم التقرير. لا يُعد السيناريو الحواري كاملًا.

## مشكلة Save Draft / Submitted

ضغطنا زرSave Draft الذي يحملid=mixed_template_draft_btn، ولم نضغطSave / Submit Template. القائمة أظهرتSubmitted. قد تكون تسمية حالة محلية أو أن التنفيذ لا يطابق اسم الزر؛ لا يوجد دليل كافٍ لإثبات وصول تقديم إلىMeta. لذلك لا يوصف القالب بأنه«مسودة مؤكدة فقط»، ولا بأنه«معتمد». لم تُرسل رسالة إلى عميل، ولم نحذف أو نفصل القالب بعد ظهوره.

هذه مشكلةUX ودلالات حالة تستحقP0 للتحقق: يجب أن تعنيSave Draft حفظًا محليًا واضحًا، وأن يكونSubmit إجراءً مستقلًا مع تأكيد وجهته. محتوى القالب تجريبي؛ الاسم النهائيaudit_travel_review_only، والمعرّف462028. قيمةLocale بقيتEnglish(US) رغم نص عربي؛ لم نختبر تعريبLocale، وهذا يؤكد أن إدخال نص عربي لا يساوي تحقق دعمRTL كامل.

## القراءة البصرية للصفحات الجديدة

- **Bot Manager —031:** بطاقات الحساب على اليسار وسياق القناة أعلى المحتوى يسهلان معرفة ما يُعدل. التبويب البنفسجي وخط الاختيار واضحان، لكن هناكRail عام ثمقائمة حسابات ثمصف تبويبات ثمصف فرعي ثمفلاتر؛ الكثافة قد تربك المبتدئ. بعض الجدول يحتاج تمريرًا أفقيًا. فيElhafez احتفظ بسياق القناة واختزل طبقات التنقل عند الدخول للمصمم.
- **Mixed Template —033:** تصميم مقسم إلىبطاقات Category/Header/Content، وLive Preview جانبية؛ اختيارText محاط بحد وخلفية خفيفة. هذا يساعد رؤية أثر الإعداد. لقطة033 التقطت قبل اكتمال تحديثBody فيPreview، ثمAX لاحق أظهرHeader وBody معًا. لا تُعد اللقطة وحدها إثبات توقيت المعاينة. الأزرار الكبيرة للفئة أفضل منDropdown مبهم، لكن خطأالاسم ظهرModal بعدالحفظ بدلشرحConstraint تحتالحقل.
- **Sequences —036:** الجدول مناسب للمقاييس، لكنالفراغ يحتاجExample/Start CTA لتعليم مستخدمجديد. Bulk Assign إجراء واسعالأثر؛ لم نستخدمه. لايمكنالحكم علىرحلةجدولةالتسلسل منالقائمة وحدها.
- **Quick Actions —037:** البطاقات/الروابط المسماة بحسبالحدث تجعلNo Match وChat with Human قابلين للاكتشاف؛ يجبأنيرىالمستخدم الفرقبين«ردافتراضي» و«حدثتحكم» حتىلايظنأنكتابةرسالةوحدها تنفذhandoff. لم نفتحالتدفقاتالموجودةأونعدلها.
- **Webhook —038:** عمودSetup واضح وPreview Empty يشرحسببالفراغ،ومساعدAI فيعمودمستقل معأمثلةمهام. هذاجيدللمبتدئ لكنيستهلكعرضًا كبيرًا قبلوجودworkflow؛فيElhafez اجعلالمساعدقابلًاللطيواشرحأنRun test قديمسأنظمةخارجية.
- **AI —040/041:** فصلEnable/Route عنAgent definition مفهومللمحترف،لكنه يتطلبشرحرحلة«أنشئثمفعّل». الحقولواسعةمعplaceholder وأقسامKnowledge. فيElhafez اعرضchecklist واحدةللخطواتالمتبقية،وأنشئالوكيلافتراضيًاInactive بدلأنيوحيActive أنهجاهزتشغيليًا.
- **Integration —042:** اختيارالمزودفيتبويباتونموذجفارغمحدودالحقول مناسب؛لم نختبرإخفاءمفتاحمحفوظأوالتحققمناتصال. شجرةالوصولأبلغتعدةتبويباتselected؛هذهإشارةتحتاجفحصوصوليةولاتكفي وحدهالإثباتحالةبصريةخاطئة.

## ما بقي غير مفحوص عند التسليم

Shared Inbox وContacts وBroadcast وConnect Account لم يُعد فحصها بعد عودة الخدمة، فتبقى آخر محاولة إليها500. Commerce/Engagement وWhatsApp Flows/Appointment لم تتجاوز روابطها المتاحة. لا محاكاة للنهاية ولاStress test ولاتصدير/استيراد فعلي ولاHandoff أوAPI Runtime. لم يدخلElhafez Boat داخليًا. توقف التوسع في الفحص عند طلب المستخدم تسليم التقرير الموجود.
