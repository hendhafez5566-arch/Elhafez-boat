# المواصفة الوظيفية والتقنية الموحدة — أساس التنفيذ

هذه وثيقة تصميم وتعاقد سلوكي؛ لا تمثل تعديلًا برمجيًا منفذًا. لا تفترض React أو مكتبة رسم بعينها أو قاعدة بيانات محددة لأن المصدر لم يُفحص. على المنفذ دمج العقود أدناه في بنية Elhafez Boat القائمة مع الحفاظ على عزل الشركات والقنوات.

## 1. النتيجة المطلوبة وحدود المعرفة

مصمم عربي سهل للمبتدئ، ويخدم المحترف بمنافذ وفروع وتحديد جماعي وإصدارات ومحاكاة. الحفظ منفصل عن النشر. لا تُرسل أي رسالة بمجرد فتح تدفق أو اختباره. المعاينة تستخدم Runtime معزولًا بمخرجات Mock، ولا تختار عميلًا حقيقيًا افتراضيًا.

مصدر المتطلبات: تجربة BotSailor في20 أكتوبر2026. شوهدت بنية نهائية من12 عقدة و11 وصلة تشمل Start وWelcome وInteractive وButton وPrograms وInput campaign وName وPhone وAcknowledgement وCondition وTrue/False. نجح حفظ أول قبل اكتمال آخر فرعين، ثم فشل حفظ لاحق وإعادة الفتح بخطأ500. بعد عودة الخدمة أعيد فتح النسخة المحفوظة:10 عقد و9 وصلات، دون آخر رسالتيTrue/False. لا توجد نتيجة تشغيلية للمحادثة. Elhafez Boat لم يتجاوز شاشة الدخول، فلا تعِد بناء الموجود دون فحصه في مرحلة التنفيذ.

## 2. هيكل الصفحات ورحلة المستخدم

Workspace → Bots → Flow list → Flow editor. كل صفحة تحمل Workspace وChannel وBot في سياق ثابت. Flow list تتضمن الاسم وحالة المسودة/النشر وآخر تعديل ومن عدّلها، وبحثًا وفلاتر. تكرار Flow ينتج Draft بهوية جديدة ودون تفعيل triggers.

فتح المصمم: تحميل آخر Draft محفوظ، والتحقق من وجود Recovery أحدث، ثم عرض المخطط. بدء تدفق جديد: Start واحدة ثم +. يستطيع المبتدئ اختيار قالب سياحة أصلي، أو اختيار رسالة أولى. يمكن للمحترف الوصول إلى كل الأنواع من Search ومفاتيح الاختصار. معاينة من البداية أو من خطوة مع قيم Sandbox.

ترتيب تنفيذ منطقي: تثبيت نموذج البيانات والحفظ → Canvas والوصلات → الرسائل/الاختيارات → الأسئلة والحقول → الشروط → Simulator → الأفعال/Handoff → الإصدارات/IO → باقي SaaS. لا يُعد وجود Canvas وحده منتجًا مكتملًا.

## 3. نموذج الوثيقة — مستقل عن مكتبة الرسم

```ts
type FlowDocument = {
  schemaVersion: 1;
  id: string;
  workspaceId: string;
  botId: string;
  channelId: string;
  name: string;
  status: 'draft' | 'published' | 'archived';
  revision: number;
  direction: 'rtl' | 'ltr';
  locale: 'ar' | 'en';
  viewport: { x: number; y: number; zoom: number };
  nodes: FlowNode[];
  edges: FlowEdge[];
  fieldRefs: FieldRef[];
  updatedAt: string;
};
type FlowNode = {
  id: string;
  type: string;
  nodeVersion: number;
  name: string;
  position: { x: number; y: number };
  config: Record<string, unknown>;
  ports: Port[];
};
type Port = {
  id: string;
  direction: 'input' | 'output';
  kind: 'control' | 'choice' | 'success' | 'error' | 'timeout';
  label: string;
  acceptedNodeTypes?: string[];
  maxConnections?: number;
};
type FlowEdge = {
  id: string;
  sourceNodeId: string;
  sourcePortId: string;
  targetNodeId: string;
  targetPortId: string;
};
type FieldRef = {
  id: string;
  key: string;
  label: string;
  scope: 'contact' | 'conversation' | 'session';
  valueType: 'text' | 'number' | 'boolean' | 'phone' | 'date' | 'enum';
};
```

لا تخزن بيانات مكتبة Canvas الداخلية كالعقد الوحيد للحقيقة. نوع العقدة وإصدارها ومعنى المنفذ مستقلون عن CSS وموضعه. IDs ثابتة؛ لا تعتمد الوصلة على index زر يتغير عند إعادة ترتيبه. تغيير اتجاه RTL/LTR يبدل العرض فقط، ولا يعكس معنى source/target أو ينشئ وصلات جديدة.

قيم JSON يجب أن تكون قابلة للتسلسل؛ لا Functions أوDOM أوSecrets. عناصر اختيار البرنامج تستعمل `choiceId` و`value` ثابتين منفصلين عن `label`. لا يستدل Runtime على نوع الحقل من اسم عربي.

## 4. Node registry

| النوع | الحد الأدنى من config | المخارج/التصرف |
|---|---|---|
| trigger | exact/contains keywords أوevent reference، أولوية، enabled | next؛ لا تفعيل إلا عند Publish |
| message.text | Body + tokens + optional delay/typing | next،error عند إرسال حقيقي |
| message.media | نوع،assetRef،caption،alt أواسم ملف | next/error؛ المعاينة المحلية لا ترفع لقناة |
| message.choice | Header/Body/Footer + choices/rows | مخرج لكلchoiceId،fallback،timeout |
| input | Prompt،type،fieldRef،required،validation،attempts | success،invalid،timeout،cancel |
| condition | combinator all/any،rules typed | true/false/error للقيمة غير قابلة للتفسير |
| action.setField | fieldRef،قيمة صريحة أوtoken | success/error |
| action.label | add/remove labelRef | success/error |
| delay | مدة أووقت محدد،timezone | next/cancel؛ Scheduler غير حاجب |
| businessHours | أسبوع وتوقيت واستثناءات | open/closed/error |
| handoff | teamRef،reason،unavailable policy | assigned/unavailable/error؛ يوقف البوت |
| subflow | flowRef،version policy،input/output mapping | success/error؛ depth limit |
| http | integrationRef،request mapping،timeout،retry | success/error/timeout؛ لا أسرار داخلFlow |
| webhook | endpointRef،payload mapping | success/error/timeout |
| ai | agentRef،allowed actions،output mapping | answered/fallback/error؛ Mock في الاختبار |
| end | reason/summary | نهاية جلسة |

MVP يشمل trigger/text/choice/input/condition/setField/end والـSimulator والحفظ؛ لا تعرض نوعًا يُنشئ عقدة شكلية بلا تنفيذ. إن كانت ميزة غير متاحة للقناة، تظهر معلومات السبب وزر بديل، لا عقدة معطلة غامضة.

## 5. الحالة التفاعلية للمحرر

حالات Canvas: idle،panning،draggingNodes،connecting،reconnecting،selectingArea،editingNode. يجب أن يكون Escape قابلًا للإرجاع إلى idle دون تغييرات جزئية. النقر على عقدة يحددها، وEnter أوDouble-click يفتح الخصائص؛ زر واضح يفعل الشيء نفسه. في Mobile تُستخدم قائمة ربط بدل الاعتماد علىDouble-click.

اختصارات مقترحة: Ctrl/Cmd+S للحفظ،Ctrl/Cmd+Z للتراجع،Ctrl/Cmd+Shift+Z للإعادة،Ctrl/Cmd+C/V للنسخ،Delete لحذف المحدد،Space+drag للتحريك،F لFit عندما Canvas هو موضع التركيز فقط. لا تعترض الاختصارات أثناء تحرير حقل نص. حذف عدة عقد ملخصه واضح وقابل للتراجع؛ حذف Flow محفوظ يتم عبر مسار المنتج وسياسة الاسترداد.

تاريخ الأوامر: إنشاء عقدة مع Edge عملية واحدة؛ سحب مجموعة من pointerdown إلىpointerup عملية واحدة؛ إعادة توجيهEdge عملية واحدة؛ كل تعديل نموذج محفوظ أمر واحد. لا يضاف Pan/Zoom لتاريخ المحتوى افتراضيًا. Clipboard ينسخ العقد المختارة ووصلاتها الداخلية؛ يعيد تعيين node/port/edge IDs؛ الوصلات إلى خارج المجموعة لا تنسخ. Clone عقدة واحدة لا ينشئ Edge إلى المصدر تلقائيًا.

## 6. الزوم والتحريك والترتيب

الإحداثيات Screen CSS pixels مقابلWorld. التحويل:`screen = world * zoom + translation`. حول المؤشر p: `world=(p-t)/z` ثم `tNew=p-world*zNew`. استخدم موضع المؤشر نسبةً لحاويةCanvas، لا نافذة المتصفح. الحدود25–200%؛ عجلة مُطبّعة لا تعتمد علىعدد الأسطر من الجهاز. Touchpad يعالج بدلالة واضحة، دون Scroll للقائمة والنموذج في الوقت نفسه.

Fit يحسب اتحاد مستطيلات العقد معpadding48px، ويضبط z ضمن الحدود؛ تدفق فارغ يعود إلىStart بمقياس100%. Reset100% يحتفظ بالنقطة العالمية وسط viewport. فتح لوحة لا ينفذFit. Auto-layout لا يغير viewport؛ يحفظ المواضع القديمة لأمرUndo واحد.

Auto-layout يتعامل مع كلConnected components، ويضع المكونات المنفصلة في مناطق مستقلة. يخصص مسارات منفصلة لـTrue/False ويترك مسافة للعقد ذات الأزرار. Align/Distribute يعمل علىالمحدد فقط. لا يُحرك تصميم المستخدم تلقائيًا عند كلحفظ.

## 7. قواعد الوصلات

الربط من output إلى input فقط، والتوافق من Registry، ومنع Edge مكرر بنفس الطرفين. مخرج القرار الواحد لا ينشئ فرعين متزامنين إلا إن كان نوعه يسمح بذلك. يسمح Fan-in لعقدة واحدة؛ Runtime ينفذها حسب المسار الفعلي. Self-loop مباشر ممنوع افتراضيًا مع شرح السبب. الدورات الأطول تُحلل: دورة تتضمن User input أو Wait يمكن السماح بها؛ دورة إرسال تلقائي بلا انتظار تمنع النشر أو تحتاج سياسة توقف صريحة.

إسقاط المنفذ في الفراغ يفتح قائمة محصورة في الأنواع المتوافقة. Escape يلغي المكون المؤقت دون أثر. إعادة توجيه Edge لا تحذف القديمة حتى التحقق من الجديدة؛ عند إسقاط غير صحيح يعود الأصل. عند تغيير نوع العقدة أو حذف زر مرتبط تظهر الوصلات المتأثرة، وتكون العملية قابلة للتراجع. لا منافذ شبح بعد إعادة ترتيب الخيارات.

## 8. التحقق من البيانات والمنطق

Validation بثلاثة مستويات: الحقل عند التعديل، والعقدة عند حفظ خصائصها، والمخطط عند الحفظ والنشر. يمكن حفظ Draft ناقصة مع Warnings، لكن Publish يمنع المخطط غير القابل للتنفيذ. أخطاء النشر: Start مفقودة، Edge بلا طرف، نوع غير مدعوم، حقل مفقود، تكامل غير جاهز، مسار حرج مفتوح، حلقة فورية غير مضبوطة. تحذيرات: عقد غير متصلة، عدم وجود Timeout، فرع Else فارغ، أسماء مكررة.

كل قاعدة شرطية تحمل `{fieldId, operator, value, valueType}`. المعاملات حسب نوع الحقل. Missing وnull وempty string حالات مختلفة؛ HasValue يعرض شرحها. لا eval لتعبير نصي. مجموعات All/Any تحفظ صراحة؛ Nested groups تؤجل إن لم تكن منفذة، ولا يعرض UI منطقًا لا يدعمه Runtime.

الاسم: trim وحد طول ومنع الفراغ؛ العربية مقبولة. الهاتف: تطبيع الأرقام العربية واللاتينية، وطلب الدولة إن لم تحدد؛ لا تستنتج EG من لغة العرض وحدها. التاريخ: نوع مفهوم مع timezone، دون خلط تاريخ فقط مع timestamp. خطأ الإدخال يعيد السؤال ويحفظ الإجابات السابقة. بعد عدد محاولات قابل للضبط يتجه إلى fallback أوhandoff، دون تكرار مزعج.

## 9. الحفظ والمسودات والإصدارات

حالة الحفظ: clean → dirty → saving → saved أو failed أو conflict. لا نجاح قبل إقرار الخادم. كل حفظ يرسل baseRevision وmutationId وdocumentHash. الخادم يفحص الصلاحية والـschema ثم يحفظ الوثيقة وrevision الجديدة ذريًا. تعارض revision يعيد409 مع نسخة الخادم ومعلومات التعارض. إعادة نفس mutationId لا تكرر الإصدار.

Autosave بعد هدوء800ms، مع حد تكرار معقول. إذا عُدّل المحتوى أثناء saving، لا يمسح إقرار النسخة القديمة dirty للنسخة الأحدث. يستمر بناء المخطط أثناء الحفظ؛ يمنع Submit مكرر لنفس النسخة فقط. الحفظ اليدوي يتجاوز انتظار debounce.

Recovery محلي: مسودة مع workspace/user/flow/revision/timestamp منفصلة عن الأسرار وبيانات الإنتاج. عند تسجيل الخروج تُطبق سياسة إزالة أو اختيار واضح للجهاز المشترك. إن فشل التخزين المحلي فلا يدّعي Banner أن المسودة محفوظة على الجهاز؛ يتيح تنزيل JSON فورًا. لا تخزن transcripts حقيقية أوTokens في Recovery.

Refresh/Open يعيد نفس IDs والمحتوى والـviewport؛ اختبار المقارنة يتجاهل التوقيتات المتغيرة. Versions قد تكون snapshots أوevent log بحسب البنية؛ Restore يصنع revision جديدة. Publish يصدر نسخة immutable منفصلة عنDraft. لا يتغير بوت حي أثناء تحرير المسودة.

عقود API مقترحة، وليست مسارات موجودة: LoadFlow،SaveDraft(baseRevision)،ValidateFlow،PublishRevision،ListVersions،RestoreVersion،ExportFlow،ImportDryRun/Commit،CreateSimulation،SendSimulationInput،ReadSimulationTrace. يمكن REST أوRPC داخل البنية الحالية؛ الدلالات والعزل والذرية هي المطلوبة.

## 10. Runtime والمحاكاة

حالة الجلسة: `{runId, flowRevision, currentNode, contactRef?, isTest, variables, waitingState, transitionCount, trace}`. يبدأ كل حدث وارد بمعرّف منع التكرار. قرار الشرط وحفظ الحقل وتقدم المسار تسجل بترتيب محدد. الانتظار حالة محفوظة قابلة للاستئناف، وليس sleep داخل معالجة الطلب. حد مستهدف:50 انتقالًا تلقائيًا لكل حدث قبل خطأ مفهوم؛ قابل للضبط بحد منصة آمن.

المحاكاة تستخدم نفس منطق message/input/condition/field mapping مع adapters بديلة للإرسال الخارجي. AI/API/Webhook/Handoff في Test تنتج Mock outcomes يختارها المستخدم. لا تنشئ أحداث عميل إنتاج أو إشعارات فريق حقيقية. سجلات Test مستبعدة من Analytics الإنتاج. Preview ثابت للقراءة يختلف عن Simulator تفاعلي؛ اشرح الفرق في الواجهة.

Trace لكل خطوة: الوقت وnodeId وportId والحالة وسبب القرار والمدة وأسماء الحقول المتغيرة، بعد إخفاء القيم الحساسة. تبويب القيم يعرض البيانات الوهمية في المحاكاة. Replay يعيد التشغيل بنسخة Flow ثابتة ونفس المدخلات؛ لا تخلط نتائج نسختين.

Handoff ليس رسالة «سنحولك للموظف» فقط. يكتب queue/assignee/reason/handoffState ويوقف أفعال البوت حتى استئناف مصرح. إذا لم يتوفر موظف يسلك unavailable أوoutside_hours. التجربة المحلية لا ترسل تنبيهًا لموظف حقيقي.

## 11. التكاملات والعزل

HTTP/Webhook يستخدمان integrationRef ومراجع أسرار خادمية، ولا يضعان المفاتيح في العقدة أوالتصدير. Test يعرض طلبًا مقنّعًا ونتائج وهمية افتراضيًا. التحقق الحقيقي الاختياري يحتاج بيئة مصرحًا بها ويبين أثره قبل التنفيذ. timeout افتراضي10s؛ Retry للأفعال القابلة للإعادة مع idempotency. لا تعد POST ذا أثر جانبي عشوائيًا. مسارا error وtimeout مطلوبان للتكاملات الحرجة.

يفحص الخادم workspaceId/channelId/flow ownership في كل قراءة وحفظ وتشغيل، ولا يكتفي بإخفاء الأزرار. الأدوار مفصلة: عرض، تحرير، نشر، تشغيل Test، إرسال حي، إدارة قنوات، إدارة فريق. الوجهات الخارجية تخضع لسياسة البيئة؛ لا تجعل URL المستخدم يسبب طلبات داخلية غير مقصودة أو كشف أسرار.

## 12. الاستيراد والتصدير

ملف Elhafez مستقل: formatId وschemaVersion وmetadata وnodes/edges وreferences دون أسرار. لا تفترض توافقًا مباشرًا مع BotSailor. يمكن لاحقًا بناء Importer بتحويل معلن للأنواع والحقول؛ لا يسمى compatible دون Round-trip حقيقي. Dry-run يوضح غير المدعوم والمراجع المفقودة. Commit ذري ويخلق Draft جديدة، دون تشغيل تلقائي.

## 13. التحليلات

Build mode بدون Counters مزدحمة. Analytics mode يعرض entered/completed/error/timeout وunique sessions والتسرب بين خطوتين. تعريف المقام الحسابي واضح؛ Sent لا يساوي Delivered ولاUnique subscriber. ترتبط البيانات بـflowRevision والقناة والفترة والمنطقة الزمنية. افصل الصفر عن عدم التحميل والخطأ. الضغط على معدل الخطأ يفتح أسبابًا وتتبّعًا منقّحًا من البيانات الحساسة.

## 14. خارطة التنفيذ والتحقق

| المرحلة | المخرج المطلوب | بوابة القبول |
|---|---|---|
|0| جرد الوضع القائم مقابلF01–F36 قبل تغييره | حالة مثبتة ودليل لكل بند |
|1| بيانات وحفظ وRecovery وConflict | A31–A38 |
|2| Canvas وPorts وUndo وZoom وLayout | A16–A30 |
|3| رسائل واختيارات وأسئلة وحقول وشروط | A01–A09 |
|4| Runtime Sandbox وHandoff | A10–A15 |
|5| RTL وResponsive وPerformance | A39–A43 |
|6| بقية SaaS والتكاملات | A44–A51 |

لا يمكن تحديد مدة تنفيذ موثوقة من فحص واجهة منافس وحدها. لا تعِد كتابة التطبيق كاملًا قبل تحديد الصالح منه. لم تُنفّذ أي مرحلة برمجية في هذه الجلسة؛ الجدول يخص التنفيذ المستقبلي.
